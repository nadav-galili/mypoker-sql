// module.exports = {
//   HOST: "localhost",
//   USER: "root",
//   PASSWORD: "",
//   DB: "mypoker",
//   multipleStatements: true,
// };

module.exports = {
  HOST: "localhost",
  USER: "pokeratv_nadavg",
  PASSWORD: "i+=&_6id$@rR",
  DB: "pokeratv_mypoker",
  multipleStatements: true,
};
