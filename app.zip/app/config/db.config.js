// module.exports = {
//   HOST: "localhost",
//   USER: "root",
//   PASSWORD: "",
//   DB: "mypoker",
//   multipleStatements: true,
// };

module.exports = {
  HOST: "localhost",
  USER: "nadavg1000",
  PASSWORD: "Barbar1000",
  DB: "pokeratv_mypoker",
  multipleStatements: true,
};
